function rankedSet=absRankAnnotator(imgIdxSet,IMDB,operDir)
operIdxSet=imgIdxSet;
rankedSet=[];
counter=1;
while ~isempty(operIdxSet)
    printset(operIdxSet,IMDB,operDir,counter);
    while 1
        topImgIdx=str2double(input(sprintf('counter=%g, top img idx?\n',counter),'s'));
        if isnumeric(topImgIdx) && ismember(topImgIdx,operIdxSet)
            rankedSet=[rankedSet;topImgIdx];
            operIdxSet(operIdxSet==topImgIdx)=[];
            counter=counter+1;
            fprintf('top img idx selected: %g\n',topImgIdx);
            break;
        else
            fprintf('invalid input, try again\n');
        end
    end
end


function printset(operIdxSet,IMDB,operDir,counter)
htmlfilename=fullfile(operDir,sprintf('%g.html',counter));

imgStr=[];
imgList=[];
for i = 1:length(operIdxSet)
    operIdx=operIdxSet(i);
    imgfilename=IMDB(operIdx).file;
    
    imgList{end+1}=imgfilename;
    imgStr{end+1}=sprintf('%g/%g imgIdx:%g',i,length(operIdxSet),operIdx);    
end

displayPatch(htmlfilename,imgList,imgStr,fullfile(operDir,sprintf('%g.html',counter-1)),fullfile(operDir,sprintf('%g.html',counter+1)),8,200,200);




