function checkIntegrity(dsidx)
global ds;
if ~dsfield(ds,'store')
    dsload('ds.store');
end


filedir=ds.store.fileDir;
operatingIdxSeq=unSyncMapper(dsidx,length(ds.store.fileList),ds.store.NBatch);

indicator=false(length(operatingIdxSeq),1);
for i = 1:length(operatingIdxSeq)
    startTime=tic;
    filename=ds.store.fileList(operatingIdxSeq(i));
    file=load(fullfile(filedir,filename.name));
    if length(file.feat)~=4 || length(file.scales)~=4 || size(file.scaledSize,1)~=4
        indicator(i)=true;
    else
        indicator(i)=false;
    end    
    timeSpent=toc(startTime);
    fprintf('%g/%g name: %s, time:%g\n',i,length(operatingIdxSeq),filename.name,timeSpent);
end
ds.res.abnormal{dsidx}=indicator;