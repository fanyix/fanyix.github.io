function computeFeatFromBbox(dsidx)
global ds;
touch;

if (~dsfield(ds,'store')),
    dsload('ds.store.operatingBboxes');
    dsload('ds.store.operatingIMDB');
    dsload('ds.store.esvmDefaultParams.init_params.sbin');
    dsload('ds.store.operatingDir');
    dsload('ds.store.templateH');
    dsload('ds.store.templateW');
    dsload('ds.store.operatingNBatch');
    dsload('ds.store.operatingOptions');
    dsload('ds.store.operatingScaledSize');
    dsload('ds.store.operatingScales');
    dsload('ds.store.operatingSpry');
end;

startTime=tic;
bboxes=ds.store.operatingBboxes;
sbin=ds.store.esvmDefaultParams.init_params.sbin;
options=ds.store.operatingOptions;
operatingIdxSeq=unSyncMapper(dsidx,size(bboxes,1),ds.store.operatingNBatch);
IMDB=ds.store.operatingIMDB;

integralFeat=cell(length(operatingIdxSeq),1);
pyrFeat=cell(length(operatingIdxSeq),1);
hogFeat=cell(length(operatingIdxSeq),1);
contextFeat=cell(length(operatingIdxSeq),1);
loc=cell(length(operatingIdxSeq),1);
info=cell(length(operatingIdxSeq),1);
for i = 1:length(operatingIdxSeq)    
    imgIdx=bboxes(operatingIdxSeq(i),5);
    [integralFeat{i} pyrFeat{i} hogFeat{i} contextFeat{i} minW minH  maxW maxH targetLv info{i}]=...
        getPoolingFeat(getIMDBProperty(imgIdx,IMDB,'origImgIdx'),bboxes(operatingIdxSeq(i),:),IMDB,sbin,ds.store.operatingSpry,...
        [ds.store.templateH ds.store.templateW],ds.store.operatingScaledSize,ds.store.operatingScales,ds.store.operatingDir,options);
    loc{i}=[minW minH maxW maxH targetLv];
end

ds.res.feat{dsidx}=integralFeat;
ds.res.pyrFeat{dsidx}=pyrFeat;
ds.res.hogFeat{dsidx}=hogFeat;
ds.res.contextFeat{dsidx}=contextFeat;
ds.res.loc{dsidx}=loc;
ds.res.info{dsidx}=info;
timeSpent=toc(startTime);
fprintf('computeFeatFromBbox: features computed from bounding boxes %g, time:%g\n',dsidx,timeSpent);