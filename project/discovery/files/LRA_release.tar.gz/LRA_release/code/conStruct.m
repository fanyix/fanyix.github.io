function structure=conStruct(w,feat,pyrFeat,imgIdx,type,moreParams)
% from the root to the leaves, the direction is going from stronger to
% weaker
switch type
    case 'specified'
        if ~exist('moreParams','var') || ~isfield(moreParams,'specifiedRanking')
            error('No specifed ranking input');
        else
            specifiedRanking=moreParams.specifiedRanking;
        end
        structure.root=1;
        for i = length(specifiedRanking):-1:1
            idx=specifiedRanking(i);
            structure.data{i}.imgIdx=idx;
            structure.data{i}.parent=i-1;
            structure.data{i}.nodeIdx=i;
            if i>1
                structure.data{i}.isParentStronger=1;
            else
                structure.data{i}.isParentStronger=0;
            end
            if ~isempty(feat)
                structure.data{i}.rankerFeat=feat(:,imgIdx==idx);
            else
                structure.data{i}.rankerFeat=[];
            end
            if ~isempty(pyrFeat)
                structure.data{i}.pyrFeat=pyrFeat(:,imgIdx==idx);
            else
                structure.data{i}.pyrFeat=[];
            end
        end
    case 'chain'
        resp=w'*feat;
        [sortVal sortIdx]=sort(resp,'descend');
        sortedImgIdx=imgIdx(sortIdx);
        structure.root=1;
        for i = length(sortedImgIdx):-1:1
            structure.data{i}.imgIdx=sortedImgIdx(i);
            structure.data{i}.parent=i-1;
            structure.data{i}.nodeIdx=i;
            if i>1
                structure.data{i}.isParentStronger=1;
            else
                structure.data{i}.isParentStronger=0;
            end
            if ~isempty(feat)
                structure.data{i}.rankerFeat=feat(:,sortIdx(i));
            else
                structure.data{i}.rankerFeat=[];
            end
            if ~isempty(pyrFeat)
                structure.data{i}.pyrFeat=pyrFeat(:,sortIdx(i));
            else
                structure.data{i}.pyrFeat=[];
            end
        end
        
        %!!!!!!!!! NOTE: if it is a general tree instead of a chain, always
        %remember to put nodes in a BFS traverse manner 
    case 'grid'
        structure.root=1;
        oneSideLength=moreParams.length;
        ranking=moreParams.ranking;
        stride=moreParams.stride;
        
        for i = oneSideLength:-1:1
            structure.data{2*i}.imgIdx=ranking(i+stride-1);
            structure.data{2*i}.nodeIdx=2*i;
            structure.data{2*i}.parent=2*i-1;
            structure.data{2*i}.isParentStronger=1;
            structure.data{2*i}.rankerFeat=[];
            structure.data{2*i}.pyrFeat=[];
            
            structure.data{2*i-1}.imgIdx=ranking(i);
            structure.data{2*i-1}.nodeIdx=2*i-1;
            structure.data{2*i-1}.parent=2*i-2;
            structure.data{2*i-1}.isParentStronger=-1;
            structure.data{2*i-1}.rankerFeat=[];
            structure.data{2*i-1}.pyrFeat=[];
        end
    case 'concentrate'
        structure.root=1;
        ranking=moreParams.ranking;
        for i = 1:length(ranking)-1
            structure.data{i}.imgIdx=ranking(i);
            structure.data{i}.nodeIdx=i;
            structure.data{i}.parent=length(ranking);
            structure.data{i}.isParentStronger=-1;
            structure.data{i}.rankerFeat=[];
            structure.data{i}.pyrFeat=[];
        end
        idx=length(ranking);
        structure.data{idx}.imgIdx=ranking(idx);
        structure.data{idx}.nodeIdx=idx;
        structure.data{idx}.parent=0;
        structure.data{idx}.isParentStronger=0;
        structure.data{idx}.rankerFeat=[];
        structure.data{idx}.pyrFeat=[];
    otherwise 
        error('unknown type of strucutre');
end

