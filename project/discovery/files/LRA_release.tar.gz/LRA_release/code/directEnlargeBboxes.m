function bboxes=directEnlargeBboxes(bboxes,rate)
hgt=bboxes(:,4)-bboxes(:,2);
wid=bboxes(:,3)-bboxes(:,1);
bboxes(:,1:4)=[bboxes(:,1)-wid*rate, bboxes(:,2)-hgt*rate, bboxes(:,3)+wid*rate, bboxes(:,4)+hgt*rate];
