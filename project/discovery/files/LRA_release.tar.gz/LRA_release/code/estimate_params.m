function [lambda c_appr c_proj c_resp c_context]=estimate_params(w,structure,iter)
% structureData=structure.data;
% nodeIdx=cellfun(@(x)x.nodeIdx,structureData);
% rankerFeat=cellfun(@(x)x.rankerFeat,structureData,'uniformoutput',false);
% rankerFeat=cat(2,rankerFeat{:});
% pyrFeat=cellfun(@(x)x.pyrFeat,structureData,'uniformoutput',false);
% pyrFeat=cat(2,pyrFeat{:});
% resp=w'*rankerFeat;
% dist=pdist2(pyrFeat',pyrFeat');
% projDist=[];
% apprDist=[];
% for i = length(structureData):-1:2
%     par=find(structureData{i}.parent==nodeIdx);
%     projDist(end+1)=resp(par)-resp(i);
%     apprDist(end+1)=dist(par,i);
% end


% rankerFeat=cellfun(@(x)x.rankerFeat,structure.data,'uniformoutput',false);
% rankerFeat=cat(2,rankerFeat{:});
% r=w'*rankerFeat;


% lambda=0.01;
% c_appr=0;
% c_context=1/10;
% % c_proj=mean(apprDist)/mean(max(-projDist+lambda,0));
% c_proj=0;% Let's empirically set c_proj to be iter, so that c_proj increase over iteration
% c_resp=0.08;%1/20+0.05*(iter-1);


lambda=0.01;
c_appr=1;
c_context=1/20;
% c_proj=mean(apprDist)/mean(max(-projDist+lambda,0));
c_proj=0;% Let's empirically set c_proj to be iter, so that c_proj increase over iteration
%1/20+0.05*(iter-1);
c_resp=0.08;% it turns out 0.08 might be a good value for the shoe and utzap50k dataset





