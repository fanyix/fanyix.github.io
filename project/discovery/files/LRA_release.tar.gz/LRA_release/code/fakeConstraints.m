function constraints=fakeConstraints(bboxes,attridx)
constraints=[];
for i = 1:size(bboxes,1)-1
    entry=[bboxes(i,5) bboxes(i+1,5) attridx 1 1 1  1];
    constraints=[constraints;entry];
end
