function constraints=formConstraints(structure,attrIdx)
structureData=structure.data;
nodeIdx=cellfun(@(x)x.nodeIdx,structureData);
constraints=[];
for i = length(structureData):-1:1
    imgIdx=structureData{i}.imgIdx;
    if structureData{i}.parent==0
        continue;
    end
    parentImgIdx=structureData{structureData{i}.parent==nodeIdx}.imgIdx;
    constraints=[constraints;parentImgIdx imgIdx attrIdx convertRA(structureData{i}.isParentStronger) 1 1 1];
end



function out=convertRA(in)
% helper function that converts {1,-1} to {1,2}
if in~=1 && in~=-1
    error('input is in an invalid domain');
end
if in==1
    out=1;
else
    out=2;
end