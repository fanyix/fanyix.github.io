function constraints=generateConstraints(constraints)

% convert all inequality into first>second
constraints=convertIneq(constraints);

uAttrIdx=unique(constraints(:,3));

attrConstraintsBag=cell(length(uAttrIdx),1);
for attrIdx=1:length(uAttrIdx)
    operConstraints=constraints(constraints(:,3)==uAttrIdx(attrIdx),:);
    
    equalityIdxSeq=(operConstraints(:,4)==3);
    eqConstraints=operConstraints(equalityIdxSeq,:);
    ineqConstraints=operConstraints(~equalityIdxSeq,:);
    extConstraints=[];
    for i=1:size(eqConstraints,1)
        firstidx=eqConstraints(i,1);
        secidx=eqConstraints(i,2);

        % process firstidx
        indicator=reshape(firstidx==vec(ineqConstraints(:,1:2)),[],2);
        sub=ineqConstraints(indicator(:,1),:);
        sub(:,1)=secidx;
        extConstraints=[extConstraints;sub];
        sub=ineqConstraints(indicator(:,2),:);
        sub(:,2)=secidx;
        extConstraints=[extConstraints;sub];

        % process secidx
        indicator=reshape(secidx==vec(ineqConstraints(:,1:2)),[],2);
        sub=ineqConstraints(indicator(:,1),:);
        sub(:,1)=firstidx;
        extConstraints=[extConstraints;sub];
        sub=ineqConstraints(indicator(:,2),:);
        sub(:,2)=firstidx;
        extConstraints=[extConstraints;sub];
    end

    operConstraints=[operConstraints;extConstraints];
    attrConstraintsBag{attrIdx}=operConstraints;
end
constraints=cat(1,attrConstraintsBag{:});

function constraints=convertIneq(constraints)
ineqidx=find(constraints(:,4)~=3);
flippedidx=constraints(ineqidx,4)==2;
ineqidx=ineqidx(flippedidx);
constraints(ineqidx,1:2)=fliplr(constraints(ineqidx,1:2));
constraints(ineqidx,4)=1;

