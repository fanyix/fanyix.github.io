function [integralFeat pyrFeat hogFeat contextFeat minW minH  maxW maxH targetLv info integralMap]=getPoolingFeat(imgIdx,bbox,IMDB,sbin,spry,sw,scaledSize,scales,integralDir,options)
info=[];
integralFeat=[];
pyrFeat=[];
minW=[];
minH=[];
maxW=[];
maxH=[];
targetLv=[];
contextFeat=[];
options.padder=0;% this is necessary
if ~isfield(options,'half') || isempty(options.half)
    options.half=false;
end

I=readImIMDB(imgIdx,IMDB);
imgSize=getIMDBProperty(imgIdx,IMDB,'size');

if options.half
    % crop back
    I=I(:,1:round(size(I,2)/2),:);
    imgSize(2)=round(imgSize(2)/2);
    scaledSize(:,2)=round(scaledSize(:,2)/2);
    bbox(1:4)=clip_to_image(round(bbox(1:4)),[1 1 imgSize(2) imgSize(1)]);
end


[sizer idealBboxes]=searchMatching(bbox,imgSize,scaledSize,sbin);
if size(bbox,2)<6
    % we use the match in the maximum frame when the size is not specified
    bbox(6:7)=sizer(1,:);
end
if options.trainRanker
    if isfield(options,'integralMap') && ~isempty(options.integralMap)
        integralMap=options.integralMap;
    else
        [integralMap]=loadCodeMap(integralDir,imgIdx,sbin);
        if options.half
            for kk=1:length(integralMap)
                integralMap{kk}=integralMap{kk}(:,1:round(size(integralMap{kk},2)/2),:);
            end
        end
        [integralMap]=integrateMap(integralMap,I,true);
    end
    [integralFeat pyrFeat minW minH maxW maxH targetLv]=matchPatch(integralMap,spry,idealBboxes,sizer,bbox(6),bbox(7),sbin);    
end

% get pedro hog here
% increase the level of hog pyramid
% if options.flexiblePyrLevel
%     % interval=3;
%     % MAXLEVEL=8;
%     % detect_max_scale=1.0;
%     % sc=2^(1/interval);
%     %enhancedScales=detect_max_scale./(sc.^((1:MAXLEVEL)-1));
%     extRatio=options.extRatio;
%     enhancedScales=sort(unique([scales scales/extRatio]),'descend');
%     [pedroHog enhancedScaledSize]=pedroHogFixedScales(I,enhancedScales);
%     pedroHog=fakePadding(pedroHog,enhancedScaledSize);
%     [hogMasker hogSizer]=searchMatching(bbox,IMDB(imgIdx).size,enhancedScaledSize,sbin);
%     [hogFeat]=matchPatchForHog(pedroHog,hogMasker,hogSizer,bbox(6),bbox(7),sbin);
%     info.enhancedScales=enhancedScales;
%     info.enhancedScaledSize=enhancedScaledSize;
% else
%     % use the same level as the pooling feature does
%     pedroHog=pedroHogFixedScales(I,scales);
%     pedroHog=fakePadding(pedroHog,scaledSize);
%     [hogFeat]=matchPatchForHog(pedroHog,masker,sizer,bbox(6),bbox(7),sbin);
% end
% use the same level as the pooling feature does
pedroHog=pedroHogFixedScales(I,scales);
[pedroHog coord]=fakePadding(pedroHog,scaledSize);
[hogFeat hogWStart hogHStart  hogWEnd hogHEnd hogTargetLv]=matchPatchForHog(pedroHog,idealBboxes,sizer,bbox(6),bbox(7),sbin);

if options.isJointFeat
    % TODO
    %hogFeat=reshape(subnorm(vec(hogFeat)',numel(hogFeat))',size(hogFeat));
    %hogFeat=hogFeat*0;
    contextExtRate=options.contextExtRate;
    
    %[expandedMask expandedSizer]=expandMask(masker,contextExtRate);
    %[ignore contextFeat]=matchPatch(integralMap,spry,expandedMask,expandedSizer,expandedSizer(targetLv,1),expandedSizer(targetLv,2),sbin);
    %contextFeat=contextFeat*0;
    if hogHStart>=1 && hogHStart<=length(coord{hogTargetLv}.markerH)
        markerH=coord{hogTargetLv}.markerH(hogHStart);
    else
        markerH=floor((hogHStart-1)/sbin)+1;
    end
    if hogWStart>=1 && hogWStart<=length(coord{hogTargetLv}.markerW)
        markerW=coord{hogTargetLv}.markerW(hogWStart);
    else
        markerW=floor((hogWStart-1)/sbin)+1;
    end
    
    contextHogMap=pedroHogFixedScales(I,scales(hogTargetLv)/(1+2*contextExtRate));    
    contextHogMap=contextHogMap{1};
    contextHogMap=padarray(contextHogMap,[options.padder options.padder 0], 0);
    o=max([markerH markerW],1)-options.padder;
    bbs=([o(:,2) o(:,1) o(:,2)+size(hogFeat,2)-1 o(:,1)+size(hogFeat,1)-1]);
    w=bbs(:,3)-bbs(:,1)+1;
    h=bbs(:,4)-bbs(:,2)+1;
    HSize=size(contextHogMap,1);
    WSize=size(contextHogMap,2);
    contextWStart=(bbs(:,1)-contextExtRate*w)/(1+2*contextExtRate);
    contextHStart=(bbs(:,2)-contextExtRate*h)/(1+2*contextExtRate);
    contextBbox=[contextWStart contextHStart contextWStart+size(hogFeat,2)-1 contextHStart+size(hogFeat,1)-1];
    % pad zeros so that we can crop out the context patches
    contextBbox=round(contextBbox+options.padder);
    
    hmp=max(1-contextBbox(2),0);
    wmp=max(1-contextBbox(1),0);
    hpp=max(contextBbox(4)-HSize,0);
    wpp=max(contextBbox(3)-WSize,0);
    paddedHogMap=padarray(contextHogMap,[hmp wmp],0,'pre');
    paddedHogMap=padarray(paddedHogMap,[hpp wpp],0,'post');
    shiftedBbox=[contextBbox(1)+wmp contextBbox(2)+hmp contextBbox(3)+wmp contextBbox(4)+hmp];
    contextFeat=vec(paddedHogMap(shiftedBbox(2):shiftedBbox(4),shiftedBbox(1):shiftedBbox(3),:));
    % TODO
    %contextFeat=contextFeat*0;
    
    
    
    % % DEBUG CODE
    % subplot(1,3,1);
    % o=[contextBbox(2) contextBbox(1)];
    % contextBbox = ([o(:,2) o(:,1) o(:,2)+size(hogFeat,2) o(:,1)+size(hogFeat,1)] - 1) .* repmat(sbin./(scales(hogTargetLv)/(1+2*contextExtRate)),1,4) + 1 + [0 0 -1 -1];
    % plotI=I;
    % plotI=plot_bb(plotI,contextBbox,'r');
    % plotI=plot_bb(plotI,bbox,'b');
    % imshow(plotI);
    % title('r--context; b--orig');
    % subplot(1,3,2);
    % imshow(HOGpicture(reshape(contextFeat,size(hogFeat))));
    % title('context');
    % subplot(1,3,3);
    % imshow(HOGpicture(hogFeat));
    % title('orig');
end

% % a piece of code for debugging
% subplot(1,2,1)
% imshow(plot_bb(I,bbox,'r'));
% subplot(1,2,2);
% imshow(HOGpicture(hogFeat));


info.pyramidSize=scaledSize;
info.sw=sw;
info.selectedSW=[bbox(6) bbox(7)];
info.stepsize=sbin*ones(size(info.pyramidSize,1),1);









