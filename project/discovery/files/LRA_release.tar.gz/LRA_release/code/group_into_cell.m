function groups = group_into_cell(M)
groups = arrayfun(@(x)M(x,:),1:size(M,1),'uniformoutput',false);