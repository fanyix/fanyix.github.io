function [map]=integrateMap(map,I,notcum)
if ~exist('notcum','var')
    notcum=false;
end

colorPallete=[1 1 0;
                            1 0 1;
                            0 1 1;
                            1 0 0;
                            0 1 0;
                            0 0 1;
                            1 1 1;
                            0 0 0];

for i = 1:length(map)
    map{i}(:,:,end)=0;
    
    % TODO: discretize to add color features
    % scaled=imresize(I,[size(map{i},1) size(map{i},2)]);
    % scaledFlat=reshape(scaled,[],3);
    % colorDist=pdist2(scaledFlat,colorPallete);
    % const=2;
    % colorDistProb=exp(-const*colorDist);
    % colorDistProb=bsxfun(@rdivide,colorDistProb,sum(colorDistProb,2));
    % scaled=reshape(colorDistProb,[size(scaled,1) size(scaled,2) size(colorPallete,1)])/10;
    % map{i}=cat(3,map{i},scaled);
end

if ~notcum
    for i = 1:length(map)
        map{i}=cumsum(map{i},1);
        map{i}=cumsum(map{i},2);
    end
end


