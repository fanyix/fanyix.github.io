function score=kendallScore(estimate,gt)

[ignore pruneidx]=setdiff(estimate,gt);
if ~isempty(pruneidx)
    estimate(pruneidx)=[];
    warning('estimate and gt not consistent');
end
[ignore pruneidx]=setdiff(gt,estimate);
if ~isempty(pruneidx)
    gt(pruneidx)=[];
    warning('estimate and gt not consistent');
end


% corridx_i contains the real rank of estimate_i
[ignore corridx]=ismember(estimate,gt);
corridx=vec(corridx);

detMat=bsxfun(@minus,corridx,corridx');
detMat=triu(detMat);
N=length(gt);
totalConf=N*(N-1)/2;
correct=sum(vec(detMat<0));
incorrect=totalConf-correct;
score=(correct-incorrect)/totalConf;