function paramsChecking(params)
% if params.spry(1)~=1
%     error('Assume that spry starts with "1" which means that the first atomN column!');
% end

if sum(params.templateW==sort(params.templateW,'descend'))~=length(params.templateW)
    error('ds.store.templateW is not in decreasing order!');
end

if sum(params.templateH==sort(params.templateH,'descend'))~=length(params.templateH)
    error('ds.store.templateH is not in decreasing order!');
end