function [feat scale scaledSize] = pixelwiseSIFTPyramid(im,sbin,requiredPixelN,MINDIMENSION)
% extract dense SIFT at every pixel
% Fanyi Xiao
if nargin==0
    feat=128;
    return;
end



%Make sure image is in double format
im=im2double(im);
if ~exist('sbin','var')
  sbin=8;
end

% scales
detect_max_scale=sqrt(requiredPixelN/(size(im,1)*size(im,2)));
detect_min_scale=0.3;
%maximum number of levels in the pyramid and the levels per octave;[5,3] for utzap50k, [3 2] for LFW10
MAXLEVELS=3;
interval=2;
sc=2 ^(1/interval);


% Start at detect_max_scale, and keep going down by the increment sc, until
% we reach MAXLEVELS or detect_min_scale
scale=zeros(1,MAXLEVELS);
scaledSize=zeros(MAXLEVELS,2);
feat={};
paddingN=6;
for i = 1:MAXLEVELS
    scaler=detect_max_scale/sc^(i-1);
    %sbin=max(1,round(8*scaler/detect_max_scale));
    if scaler<detect_min_scale
        scale=scale(1:i-1);
        scaledSize=scaledSize(1:i-1,:);
        return
    end
    
    scale(i)=scaler;
    scaled=myimresize(im,scale(i));
    scaledSize(i,:)=[size(scaled,1) size(scaled,2)];
    
    % %if minimum dimensions is less than or equal to MINDIMENSION, exit
    % if min([size(scaled,1) size(scaled,2)])<=MINDIMENSION || min(size(scaled,1),size(scaled,2))<=sbin*4
    %     scale=scale(1:i-1);
    %     scaledSize=scaledSize(1:i-1,:);
    %     return;
    % end
    tmpI=padarray(scaled,[paddingN paddingN],'symmetric','both');
    tmpI=im2single(rgb2gray(tmpI));
    [f,d]=vl_dsift(tmpI,'step',1,'size',4);
    d=single(d);
    feat{i}=assembleDSIFT(d,scaled);
    
    %if we get zero size feature, backtrack one, and dont produce any
    %more levels
    if (size(feat{i},1)*size(feat{i},2)) == 0 || min(size(feat{i},1),size(feat{i},2))<=MINDIMENSION
        feat = feat(1:i-1);
        scale=scale(1:i-1);
        scaledSize=scaledSize(1:i-1,:);
        return;
    end
end

function d=assembleDSIFT(d,im)
m=size(im,1);
n=size(im,2);
d=d';
featDim=size(d,2);
d=reshape(d,[m n featDim]);











