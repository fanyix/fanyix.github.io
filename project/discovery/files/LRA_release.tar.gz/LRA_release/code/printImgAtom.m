function printImgAtom(bboxes,IMDB,printdir)
for i = 1:size(bboxes,1)
    imgidx=bboxes(i,5);
    imgFilename=fullfile(printdir,sprintf('%g.jpg',imgidx));
    img=readImIMDB(imgidx,IMDB);
    img=plot_bb(img,bboxes(i,1:4),'r');
    myimwrite(img,imgFilename);
end