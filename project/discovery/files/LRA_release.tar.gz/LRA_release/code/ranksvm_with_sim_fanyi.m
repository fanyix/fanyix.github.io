function w = ranksvm_with_sim_fanyi(X,A,B,C_A, C_B,w)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by Fanyi Xiao, for better optimization <fanyix.cs@gmail.com> on
% 09/03/2014


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by Rishabh Raj <rishabh.raj@students.iiit.ac.in> on 01/20/2014
% to fix an error pointed out by Siddhartha Chaudhuri
% <sidch@cs.princeton.edu>. See line 142.
%
% Modified by Devi Parikh on 03/10/2012 to incorporate similarity
% constraints in Olivier Chapelle's implementation:
% http://olivier.chapelle.cc/primal/ranksvm.m at
% http://olivier.chapelle.cc/primal/
%
% w = ranksvm_with_sim(X,O,S,C_O,C_S,w,opt)
%
% X contains the training inputs / feature vectors and is an n x d matrix
% (n = number of points, d is dimensionality of each point).
%
% O is a sparse p x n matrix, where p is the number of preference ordered
% pairs. Each row of O should contain exactly one +1 and one -1. If the Pth
% preference pair says i > j (strength of attribute in image i is greater
% than strength of attribute in image j) then O(p,i) = 1 and O(p,j) = -1;
%
% Similarly, S is a sparse p x n matrix, where p is the number of
% preference unordered pairs that have similar strengths of the attribute.
% Each row of S should contain exactly one +1 and one -1.
%
% C_O and C_S are vectors of training error penalizations (one for each
% preference pair). In Parikh and Grauman, Relative Attributes, ICCV 2011,
% these were set to 0.1.
%
% w is an initialization of the weight vector to be learnt (default is 0's).
% 
% opt (as described by Olivier Chappelle below) s a structure containing the
% options (in brackets default values): 
%   lin_cg: Find the Newton step, by linear conjugate gradients [0]
%   iter_max_Newton: Maximum number of Newton steps [20]
%   prec: Stopping criterion
%   cg_prec and cg_it: stopping criteria for the linear CG.
%
% If you use this code, please cite:
% Devi Parikh and Kristen Grauman
% Relative Attributes
% International Conference on Computer Vision (ICCV) 2011
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Old documentation by Olivier Chapelle
%
% W = RANKSVM(X,A,C,W,OPT)
% Solves the Ranking SVM optimization problem in the primal (with quatratic
%   penalization of the training errors).
%
% X contains the training inputs and is an n x d matrix (n = number of points).
% A is a sparse p x n matrix, where p is the number of preference pairs.
%   Each row of A should contain exactly one +1 and one -1
%   reflecting the indices of the points constituing the pairs.
% C is a vector of training error penalizations (one for each preference pair).
%
% OPT is a structure containing the options (in brackets default values):
%   lin_cg: Find the Newton step, by linear conjugate gradients [0]
%   iter_max_Newton: Maximum number of Newton steps [20]
%   prec: Stopping criterion
%   cg_prec and cg_it: stopping criteria for the linear CG.

% Copyright Olivier Chapelle, olivier.chapelle@tuebingen.mpg.de
% Last modified 25/08/2006

n0 = size(A, 1);
d = size(X,2);
if nargin<6
    w=zeros(d,1);
end;
C = [C_A; C_B];
A = [A;B];

options=[];
% options.display = 'none';
options.Method = 'lbfgs';
options.maxFunEvals = 10000;
options.TolX = 1e-20;
options.Display='off';

% check gradient
% w0=rand(d,1);
% [J0 g0] = obj_fun_linear_fanyi(w0,C,X,A,n0);
% numgrad = computeNumericalGradient(@(x) obj_fun_linear_fanyi(x,C,X,A,n0), w0);
% disp([g0 numgrad]); 
% norm(g0-numgrad)

w=minFunc(@obj_fun_linear_fanyi,w,options,C,X,A,n0);
[obj, grad, sv] = obj_fun_linear_fanyi(w,C,X,A,n0);


