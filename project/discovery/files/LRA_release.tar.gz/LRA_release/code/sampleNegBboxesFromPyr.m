function res=sampleNegBboxesFromPyr(imgSizes,bboxes,pyrSize,SW,N,minDim,isThresh)

NPS=ceil(N/(size(SW,1)));%number per sliding window size
myRandSeeding;
if ~exist('isThresh','var')
    isThresh=0.2;
end
maxTrial=100;
res=[];


for i = 1:size(imgSizes,1)
    bbox=bboxes(i,:);
    imgSize=imgSizes(i,:);
    % sample for one image
    templateSize=pyrSize(i,:);
    hStretch=templateSize(1)/imgSize(1);
    wStretch=templateSize(2)/imgSize(2);
    for k = 1:size(SW,1)
        sw=SW(k,:);
        counter=0;
        bingo=0;
        confirmBbox=[];
        while 1
            hS=randi(templateSize(1)-sw(1)+1,NPS,1);
            wS=randi(templateSize(2)-sw(2)+1,NPS,1);
            hE=hS+sw(1)-1;
            wE=wS+sw(2)-1;
            tentBbox=[hS/hStretch wS/wStretch hE/hStretch wE/wStretch];
            [ignore inter]=getosmatrix_bb(tentBbox,bbox(1:4));
            valIdx=inter<isThresh;
            confirmBbox=[confirmBbox;tentBbox(valIdx,:)];
            if size(confirmBbox,1)>=NPS
                bingo=1;
                break;
            end
            if counter>=maxTrial
                break;
            end
            counter=counter+1;
        end
        if ~bingo
            continue;
        end
        confirmBbox=confirmBbox(1:NPS,:);
        confirmBbox=clip_to_image(round(confirmBbox),[1 1 imgSize(2) imgSize(1)]);
        resEntry=[confirmBbox bbox(5)*ones(NPS,1) sw(1)*ones(NPS,1) sw(2)*ones(NPS,1)];
        res=[res;resEntry];
    end
end

pruneIdx=res(:,4)-res(:,2)<=minDim | res(:,3)-res(:,1)<=minDim;
res(pruneIdx,:)=[];

% % DEBUG code
% global ds;
% for i = 1:size(bboxes,1)
%     I=readImIMDB(bboxes(i,5),ds.store.IMDB);
%     I=plot_bb(I,bboxes(i,:),'r');
%     negBboxes=res(res(:,5)==bboxes(i,5),:);
%     [ignore inter]=getosmatrix_bb(negBboxes,bboxes(i,:));
%     for j = 1:size(negBboxes)
%         I=plot_bb(I,negBboxes(j,:),'b');
%     end
%     imshow(I);
%     title(sprintf('%g/%g, max IS:%g',i,size(bboxes,1), max(inter)));
%     pause;
% end





