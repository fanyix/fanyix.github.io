function [accRes]=testDeepFeat(trConstraints,trBboxes,valConstraints,valBboxes,fc7Feat)

feat=double(fc7Feat(:,trBboxes(:,5)));
valFeat=double(fc7Feat(:,valBboxes(:,5)));
feat=subnorm(feat',size(feat,1))';
valFeat=subnorm(valFeat',size(valFeat,1))';

involvingImgIdx=unique(vec(trConstraints(:,1:2)));
[ignore involvingBboxesIdx]=ismember(involvingImgIdx,trBboxes(:,5));
if sum(involvingBboxesIdx==0)>0
    error('There are images in the constraints that are not provided with bounding boxes');
end

[ignore localIdx]=ismember(vec(trConstraints(:,1:2)),involvingImgIdx);% transform image index into local index
localConstraints=trConstraints;
localConstraints(:,1:2)=reshape(localIdx,[size(trConstraints,1) 2]);

% form the constraint structure for learning
imgN=length(involvingImgIdx);

inequality=localConstraints(localConstraints(:,4)<3,:);
O=zeros(size(inequality,1),imgN);
isFirstWin=inequality(:,4)==1;
strongIdx=zeros(size(inequality,1),1);
strongIdx(isFirstWin)=inequality(isFirstWin,1);
strongIdx(~isFirstWin)=inequality(~isFirstWin,2);
strongIdx=sub2ind(size(O), (1:size(inequality,1))', strongIdx);
weakIdx=zeros(size(inequality,1),1);
weakIdx(isFirstWin)=inequality(isFirstWin,2);
weakIdx(~isFirstWin)=inequality(~isFirstWin,1);
weakIdx=sub2ind(size(O), (1:size(inequality,1))', weakIdx);
O(strongIdx)=1;
O(weakIdx)=-1;
coSeq=inequality(:,5).*inequality(:,6);
isTrain=inequality(:,7);

equality=localConstraints(localConstraints(:,4)==3,:);
S=zeros(size(equality,1),imgN);
strongIdx=equality(:,1);
weakIdx=equality(:,2);
strongIdx=sub2ind(size(S), (1:size(equality,1))', strongIdx);
weakIdx=sub2ind(size(S), (1:size(equality,1))', weakIdx);
S(strongIdx)=1;
S(weakIdx)=-1;
csSeq=equality(:,5).*equality(:,6);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% learn ranker 
% do cross-validation to determine C_O and C_S
if ~isempty(valBboxes)&&~isempty(valConstraints)
    cArray=10.^(-2:1:4);
    acc=zeros(length(cArray),1);
    for i = 1:length(cArray)
        w=ranksvm_with_sim_fanyi(feat(:,involvingBboxesIdx)',O,S,cArray(i)*coSeq,cArray(i)*csSeq);
        acc(i)=judgeStandard(w,valBboxes,valFeat,valConstraints);
        %r=w'*feat(:,involvingBboxesIdx);
        %acc(i)=judgeSparse(r,O(~isTrain,:));
        fprintf('cross val -- c=%g\n',cArray(i));
    end
    [cvAcc maxIdx]=max(acc);
    C=cArray(maxIdx);
    fprintf('cross val -- best c=%g, cv acc=%g\n',C,cvAcc);
else
    C=100;
    cvAcc=nan;
end
wFinal=ranksvm_with_sim_fanyi(feat(:,involvingBboxesIdx)',O,S,C*coSeq,C*csSeq);
r=wFinal'*feat(:,involvingBboxesIdx);
trAcc=judgeSparse(r,O);

accRes=[];
accRes.C=C ; 
accRes.cvAcc=cvAcc ; 
accRes.trAcc=trAcc;


