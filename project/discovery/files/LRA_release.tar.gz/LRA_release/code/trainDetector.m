function [detector models]=trainDetector(hogFeat,neg_set,avoidBboxes,scales,options)
global ds;

esvmParams=ds.store.esvmDefaultParams;
% esvmParams.dataset_params.localdir=tmpLRADetModelDir;
esvmParams.detect_max_scale = 0.5;
esvmParams.detect_exemplar_nms_os_threshold = 1.0; 
esvmParams.detect_max_windows_per_exemplar = 100;
esvmParams.train_max_mined_images=1000;
esvmParams.detect_save_features=1;
esvmParams.train_svm_c=1e-2;
esvmParams.train_positives_constant=5;
esvmParams.detect_keep_threshold=-2;
esvmParams.detect_add_flip=false;
esvmParams.detect_max_windows_per_exemplar=1000;
esvmParams.specifiedScales=scales;
% TODO: do we need this?
% esvmParams.detect_pyramid_padding=0;

max_negN_main_thread=8000;
posx=cellfun(@(x)vec(x),hogFeat,'uniformoutput',false);
posx=cat(2,posx{:});
% generate a structure to make esvm happy
m.models_name='LRA_detector_model';
m.objectid=1;
m.model.x=posx;
m.model.w=mean(posx,2);
m.model.w=m.model.w-mean(m.model.w(:));
m.model.w=reshape(m.model.w,size(hogFeat{1}));

if isfield(options,'isJointFeat') && options.isJointFeat
    m.model.contextx=options.contextFeat;
    m.model.contextw=mean(options.contextFeat,2);
    m.model.contextw=m.model.contextw-mean(m.model.contextw(:));
end
options.withIMDB=false;

m.model.b = 0;
m.model.hg_size=size(m.model.w);
m.model.init_params.sbin=esvmParams.init_params.sbin;
m.mining_params=esvmParams;
models=[];
models{1}=m;

% apply detector to mine hard negatives
maxHardNegIter=3;
dsupWrap('ds.store.operatingOptions',options);
dsupWrap('ds.store.operatingDetectorParams',esvmParams);
dsupWrap('ds.store.operatingNegOSThresh',0.3);
dsupWrap('ds.store.operatingGetHogLayer',false);
% clear res buffer
if dsfield(ds,'res')
    dsdelete('ds.res');
end


counter=zeros(length(neg_set),1);
for mine_iter=1:maxHardNegIter
    selN=round(esvmParams.train_max_mined_images*mine_iter/maxHardNegIter);    
    selIdx=sampleFromCounter(counter,selN);
    counter(selIdx)=counter(selIdx)+1;
    models{1}.itertag=mine_iter;
    dsupWrap('ds.store.operatingDetector',models);
    dsupWrap('ds.store.operatingImgSet',neg_set(selIdx));
    if isempty(avoidBboxes)
        dsupWrap('ds.store.operatingAvoidBboxes',0);
    else
        dsupWrap('ds.store.operatingAvoidBboxes',avoidBboxes(selIdx));
    end
    % if isfield(options,'isJointFeat') && options.isJointFeat
    %     dsupWrap('ds.store.operatingImgSetIdx',options.negSetImgIdx(selIdx));
    % end
    dsupWrap('ds.store.operatingTopK',ceil(max_negN_main_thread/length(ds.store.operatingImgSet)));
    if dsmapredisopen()
        NBatch=ceil(length(ds.store.operatingImgSet)/(length(ds.sys.distproc.availslaves)*1));
    else
        NBatch=20;
    end
    batchSeq=unSyncDistribute(length(ds.store.operatingImgSet),NBatch);
    dsupWrap('ds.store.operatingNBatch',NBatch);
    dsrundistributed('mineHardNeg(dsidx);',length(batchSeq));
    resBboxes=cat(1,ds.res.bboxes{:});
    resFeat=cat(1,ds.res.feat{:});
    dsdelete('ds.res');
    pruneIdx=cellfun(@(x)~isnumeric(x),resBboxes);
    resBboxes(pruneIdx)=[];
    resFeat(pruneIdx)=[];
    negBboxes=cat(1,resBboxes{:});
    negFeat=cat(2,resFeat{:});
    
    % update svm
    if ~isfield(models{1}.model,'svxs')
        models{1}.model.svxs=negFeat;
        models{1}.model.svbbs=negBboxes;
    else
        models{1}.model.svxs=cat(2,models{1}.model.svxs,negFeat);
        models{1}.model.svbbs=cat(1,models{1}.model.svbbs,negBboxes);
    end
    if isfield(options,'isJointFeat') && options.isJointFeat
        models{1}=esvm_update_svm_jointFeat(models{1});
    else
        models{1}=esvm_update_svm(models{1});
    end
    fprintf('detector training iter %g is done, scanned # img=%g...\n\n\n\n',mine_iter,selN);
end

dsdelete('ds.store.operatingOptions');
dsdelete('ds.store.operatingDetector');
dsdelete('ds.store.operatingImgSet');
dsdelete('ds.store.operatingAvoidBboxes');
dsdelete('ds.store.operatingTopK');
dsdelete('ds.store.operatingDetectorParams');
dsdelete('ds.store.operatingNegOSThresh');
dsdelete('ds.store.operatingNBatch');
dsdelete('ds.store.operatingGetHogLayer');
detector.w=models{1}.model.w;
detector.b=models{1}.model.b;
if isfield(options,'isJointFeat') && options.isJointFeat
    %dsdelete('ds.store.operatingImgSetIdx');
    detector.contextw=models{1}.model.contextw;
end














