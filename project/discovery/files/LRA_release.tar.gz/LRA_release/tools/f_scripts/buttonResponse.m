function buttonResponse(hObject,eventdata)
a = get(gca, 'CurrentPoint');
assignin('caller', 'curHor',  a(1));
assignin('caller', 'curVer',  a(2)); 
assignin('caller', 'curFig',  hObject); 

b = get(hObject,'selectiontype');
if strcmpi(b,'alt')
    assignin('caller', 'button', 3); 
else
    assignin('caller', 'button', 1); 
end
uiresume;

