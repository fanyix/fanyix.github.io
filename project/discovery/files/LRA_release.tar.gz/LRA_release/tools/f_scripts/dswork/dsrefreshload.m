function dsrefreshload(filename)
[filedir]=fileparts(filename);
unix(sprintf('ls -la %s',filedir));
