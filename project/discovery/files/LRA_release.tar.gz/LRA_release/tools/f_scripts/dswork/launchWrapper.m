function launchWrapper(server,N,pauseTime,conf)
global ds;
if ~exist('conf','var')
    conf = struct();
end
if ~exist('pauseTime','var')
    pauseTime = 5;
end    

clear servername;
switch server
    case 'EC2'
        servername='master';
        dssetout('/home/data/localTmp/',...
            '/home/data/localTmp/',...
            '/home/code/LRA/f_scripts/dswork/');
        if(~dsmapredisopen())
            conf.runcompiled=1;
            dsmapredopenSGE(N,servername,conf);
        end
    case 'elvis'
        servername='elvis.cs.ucdavis.edu';
        dssetout('/home/fyxiao/data/localTmp/',...
            '/home/fyxiao/data/localTmp/',...
            '/home/fyxiao/code/f_scripts/dswork/');
        if(~dsmapredisopen())
            conf.runcompiled=1;
            dsmapredopenSGE(N,servername,conf);
        end
    case 'tashi'
        for i = 1:N
            servername{i} = sprintf('fanyivm%g',i);
        end
        dssetout('/homes/fanyi/esvm_package/results/localTmp/',...
            '/homes/fanyi/esvm_package/results/localTmp/',...
            '/homes/fanyi/esvm_package/f_scripts/dswork/');
        if(~dsmapredisopen())
            conf.runcompiled = 1;
            dsmapredopenVM(N,servername,conf);
            % dsmapredopen(N,'local');
        end
    case 'warp'
        servername = 'warp.hpc1.cs.cmu.edu';
        dssetout('/home/fanyix/lustre/data/localTmp/',...
            '/home/fanyix/lustre/data/localTmp/',...
            '/home/fanyix/lustre/code/f_scripts/dswork/');
        if(~dsmapredisopen())
            dsmapredopen(N,servername,conf);
        end
    case 'local'
        dssetout('/home/fanyi/datastore/localTmp/',...
            '/home/fanyi/datastore/localTmp/',...
            '/home/fanyi/esvm_package/f_scripts/dswork/');
        if(~dsmapredisopen())
            dsmapredopen(N,'local',conf);
        end
end
fprintf('Lets wait %g secs for nodes to be launched\n',pauseTime);
pause(pauseTime);


