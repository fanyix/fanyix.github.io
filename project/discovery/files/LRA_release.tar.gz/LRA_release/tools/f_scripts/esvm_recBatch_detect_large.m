function [resstruct,feat_pyramid] = esvm_recBatch_detect_large(I, models, params)
if isempty(models)
  fprintf(1,'Warning: empty models in esvm_detect\n');
  resstruct.bbs{1} = zeros(0,0);
  resstruct.xs{1} = zeros(0,0);
  feat_pyramid = [];
  return;
end

if ~iscell(models)
  models = {models};
end

if isfield(models{1},'mining_params') && ~exist('params','var')
  params = models{1}.mining_params;
elseif ~exist('params','var')
  params = esvm_get_default_params;
end

if ~isfield(params,'nnmode')
 params.nnmode = '';
end

if ~isfield(params,'save_fired_HOG_loc')
    params.save_fired_HOG_loc = 0;
end

doflip = params.detect_add_flip;

params.detect_add_flip = 0;

[rs1, t1] = esvm_detectdriverBLOCK(I, models, params);
for i = 1:length(rs1.recDetStat)
    activeBboxesIdx = rs1.recDetStat{i}.activeBboxesIdx;
    [ignore preserved_idx] = prune_nms(rs1,activeBboxesIdx,params);
    rs1.recDetStat{i}.activeBboxesIdx = cellfun(@(x,y)x(y),...
        activeBboxesIdx,preserved_idx,'uniformoutput',false);
end

if doflip == 1
  params.detect_add_flip = 1;
  [rs2, t2] = esvm_detectdriverBLOCK(I, models, params);
  for i = 1:length(rs2.recDetStat)
    activeBboxesIdx = rs2.recDetStat{i}.activeBboxesIdx;
    [ignore preserved_idx] = prune_nms(rs2,activeBboxesIdx,params);
    rs2.recDetStat{i}.activeBboxesIdx = cellfun(@(x,y)x(y),...
        activeBboxesIdx,preserved_idx,'uniformoutput',false);
  end
else %If there is no flip, then we are done
  resstruct = rs1;
  feat_pyramid = t1;
  return;
end

%If we got here, then the flip was turned on and we need to concatenate
%results
bboxesIdxOffset = zeros(length(rs1.bbs),1);
for q = 1:length(rs1.bbs)
  bboxesIdxOffset(q) = size(rs1.bbs{q},1);
  rs1.bbs{q} = cat(1,rs1.bbs{q},rs2.bbs{q});
end
for i = 1:length(rs1.recDetStat)
    for j = 1:length(rs1.recDetStat{i}.activeBboxesIdx)
        rs1.recDetStat{i}.activeBboxesIdx{j} = ...
            [rs1.recDetStat{i}.activeBboxesIdx{j} ...
            rs2.recDetStat{i}.activeBboxesIdx{j}+bboxesIdxOffset(j)];
    end
    rs1.recDetStat{i}.meanErr = ...
        [rs1.recDetStat{i}.meanErr rs2.recDetStat{i}.meanErr];
    rs1.recDetStat{i}.retrievalRate = ...
        [rs1.recDetStat{i}.retrievalRate rs2.recDetStat{i}.retrievalRate];
end
rs1.NFired = [rs1.NFired rs2.NFired];
resstruct = rs1;
%Concatenate normal and LR pyramids
feat_pyramid = cat(1,t1,t2);


function [resstruct,t] = esvm_detectdriverBLOCK(I, models, params)

%%HERE is the chunk version of exemplar localization

N = length(models);
ws = cellfun2(@(x)x.model.w,models);
bs = cellfun(@(x)x.model.b,models)';
bs = reshape(bs,[],1);
sizes1 = cellfun(@(x)x.model.hg_size(1),models);
sizes2 = cellfun(@(x)x.model.hg_size(2),models);

S = [max(sizes1(:)) max(sizes2(:))];
fsize = params.init_params.features();
D = S(1)*S(2)*fsize;
templates = zeros(S(1),S(2),fsize,length(models));
templates_x = zeros(S(1),S(2),fsize,length(models));
template_masks = zeros(S(1),S(2),fsize,length(models));

for i = 1:length(models)
  t = zeros(S(1),S(2),fsize);
  t(1:models{i}.model.hg_size(1),1:models{i}.model.hg_size(2),:) = ...
      models{i}.model.w;

  templates(:,:,:,i) = t;
  template_masks(:,:,:,i) = repmat(double(sum(t.^2,3)>0),[1 1 fsize]);

  if (~isempty(params.nnmode)) || ...
        (isfield(params,'wtype') && ...
         strcmp(params.wtype,'dfun')==1)
    x = zeros(S(1),S(2),fsize);
    x(1:models{i}.model.hg_size(1),1:models{i}.model.hg_size(2),:) = ...
        reshape(models{i}.model.x(:,1),models{i}.model.hg_size);
    templates_x(:,:,:,i) = x;
  end
end

%maskmat = repmat(template_masks,[1 1 1 fsize]);
%maskmat = permute(maskmat,[1 2 4 3]);
%templates_x  = templates_x .* maskmat;

sbin = models{1}.model.init_params.sbin;

if isfield(params,'precomputation')
    if (params.detect_add_flip == 1)
        t = params.precomputation.flip;
    else
        t = params.precomputation.orig;
    end
else
    t = get_pyramid(I, sbin, params);
end


resstruct.padder = t.padder;

available_size = cellfun(@(x)[size(x,1) size(x,2)]-S+1,t.hog,'uniformoutput',false);
available_size = cat(1,available_size{:});
val_idx = find(sum(available_size<=0,2)==0);
pyr_N = prod(available_size(val_idx,:),2);
exemplar_matrix = reshape(templates,[],size(templates,4));

% set up default loading parameters
if ~isfield(params,'patch_loading')
    params.patch_loading = 30000;
end
if ~isfield(params,'model_loading')
    params.model_loading = 3500;
end

% init params
lowRankKSeq = params.lowRankKSeq; 
reEstRatioSeq = params.reEstRatioSeq;
rankerRecipe = params.rankerRecipe;
params.detect_max_windows_per_exemplar = inf;

% initialize resstruct
resstruct.bbs = cell(N,1);
for i = 1:length(lowRankKSeq)*length(reEstRatioSeq)
    resstruct.recDetStat{i}.activeBboxesIdx = cell(N,1);
    resstruct.recDetStat{i}.meanErr = [];
    resstruct.recDetStat{i}.retrievalRate = [];
end
%resstruct.activeBboxesIdx = cell(N,1);
%resstruct.activeBboxesIdxFlat = cell(N,1);



level_counter = 0;
firingOffset = zeros(N,1);
while level_counter < length(pyr_N)
    patch_counter = 0;
    inner_level_counter = 0;
    while patch_counter < params.patch_loading && ...
            level_counter+inner_level_counter<length(pyr_N)
        patch_counter = patch_counter + pyr_N(level_counter+inner_level_counter+1);
        inner_level_counter = inner_level_counter + 1;
    end

    sumN = patch_counter;
    X = zeros(S(1)*S(2)*fsize,sumN);
    offsets = cell(inner_level_counter, 1);
    uus = cell(inner_level_counter,1);
    vvs = cell(inner_level_counter,1);
    counter = 1;
    for i = 1:inner_level_counter
      s = size(t.hog{val_idx(level_counter+i)});
      NW = s(1)*s(2);
      ppp = reshape(1:NW,s(1),s(2));
      curf = reshape(t.hog{val_idx(level_counter+i)},[],fsize);
      b = im2col(ppp,[S(1) S(2)]);
      offsets{i} = b(1,:);
      offsets{i}(end+1,:) = val_idx(level_counter+i);
      for j = 1:size(b,2)
       X(:,counter) = reshape(curf(b(:,j),:),[],1);
       counter = counter + 1;
      end
      [uus{i},vvs{i}] = ind2sub(s,offsets{i}(1,:));
    end
    if isempty(X)
        return;
    end
    offsets = cat(2,offsets{:});
    uus = cat(2,uus{:});
    vvs = cat(2,vvs{:});
    modelBatchLoading = unSyncDistribute(N,params.model_loading);
    for modelBatchNumerator= 1:length(modelBatchLoading)
        modelBatchIdx = modelBatchLoading(modelBatchNumerator);
        modelValIdx = unSyncMapper(modelBatchIdx,N,params.model_loading);
        if isempty(params.nnmode)
          %nnmode 0: Apply linear classifiers by performing one large matrix
          %multiplication and subtract bias
            r = exemplar_matrix(:,modelValIdx)' * X;
            r = bsxfun(@minus, r, bs(modelValIdx));
        elseif strcmp(params.nnmode,'elda') == 1
            r = exemplar_matrix(:,modelValIdx)' * X;
            r = bsxfun(@minus, r, bs(modelValIdx));
            [threshScore ignore] = psort(-r(:),numel(r)*0.0005);
            params.detect_keep_threshold = -threshScore(end);
        else
          error('invalid nnmode=%s\n',params.nnmode);
        end
        resstruct = collectingResults(resstruct,r,modelValIdx,uus,vvs,offsets,ws,sbin,t,params);
        resstruct.NFired = length(resstruct.activeBboxesIdxFlat);
        activeBboxesIdx = resstruct.activeBboxesIdx;
        activeBboxesIdxFlat = resstruct.activeBboxesIdxFlat;
        
        counter = 1;
        for p = 1:length(lowRankKSeq)
            lowRankK = round(lowRankKSeq(p)*D);
            %U = rankerRecipe.U(:,1:lowRankK)*rankerRecipe.D(1:lowRankK,1:lowRankK);
            U = rankerRecipe.U(:,1:lowRankK);
            V = rankerRecipe.V(:,1:lowRankK);
            regressorB = rankerRecipe.regressorB;
            % apply ranker at each window
            estR = bsxfun(@plus,V(modelValIdx,:)*(U'*X),regressorB(modelValIdx));
            for q = 1:length(reEstRatioSeq)
                reEstRatio = reEstRatioSeq(q);
                [sortedEstRVal sortedEstRIdx] = psort(-vec(estR),...
                    round(reEstRatio*numel(estR)));        
                %[estX estY] = ind2sub(size(estR),sortedEstRIdx);
                %uEstX = unique(estX);
                indicator = ismember(activeBboxesIdxFlat,sortedEstRIdx);
                retrievalRate = sum(indicator)/length(indicator);
                NActiveBboxes = cellfun(@(x)length(x),activeBboxesIdx);
                cumNActiveBboxes = [0; cumsum(NActiveBboxes)];
                indicator = arrayfun(@(x)...
                    find(indicator(cumNActiveBboxes(x)+1:cumNActiveBboxes(x+1)))+firingOffset(modelValIdx(x)),...
                    1:length(cumNActiveBboxes)-1,'uniformoutput',false);
                resstruct.recDetStat{counter}.lowRank = lowRankKSeq(p);
                resstruct.recDetStat{counter}.reEstRatio = reEstRatio;
                resstruct.recDetStat{counter}.activeBboxesIdx(modelValIdx) = ...
                    cellfun(@(x,y)cat(2,x,y),resstruct.recDetStat{counter}.activeBboxesIdx(modelValIdx),...
                    indicator','uniformoutput',false);
                resstruct.recDetStat{counter}.meanErr = ...
                    [resstruct.recDetStat{counter}.meanErr mean(abs(vec(estR-r)))];
                resstruct.recDetStat{counter}.retrievalRate = ...
                    [resstruct.recDetStat{counter}.retrievalRate retrievalRate];
                counter = counter + 1;
            end
        end
    end
    % update firingOffset
    firingOffset = cellfun(@(x)size(x,1),resstruct.bbs);
    level_counter = level_counter + inner_level_counter;
end


% post processing for resstruct
for i = 1:length(resstruct.recDetStat)
    resstruct.recDetStat{i}.meanErr = mean(resstruct.recDetStat{i}.meanErr);
    resstruct.recDetStat{i}.retrievalRate = mean(resstruct.recDetStat{i}.retrievalRate,2);
end
resstruct = rmfield(resstruct,'activeBboxesIdx');
resstruct = rmfield(resstruct,'activeBboxesIdxFlat');


function resstruct = collectingResults(resstruct,r,modelValIdx,...
    uus,vvs,offsets,ws,sbin,t,params)
if size(r,1)~=length(modelValIdx)
    error('The model set size mismatch!');
end
resstruct.activeBboxesIdx = cell(length(modelValIdx),1);
resstruct.activeBboxesIdxFlat = cell(length(modelValIdx),1);

for exid = 1:length(modelValIdx)
    goods = find(r(exid,:) >= params.detect_keep_threshold);
    if isempty(goods)
        continue    
    end
    modelIdx = modelValIdx(exid);
    [sorted_scores,bb] = ...
      psort(-r(exid,goods)',...
            min(params.detect_max_windows_per_exemplar, ...
                length(goods)));
    bb = goods(bb);
    sorted_scores = -sorted_scores';
    %resstruct.xs{modelIdx} = [resstruct.xs{modelIdx} X(:,bb)];
    levels = offsets(2,bb);
    scales = t.scales(levels);
    curuus = uus(bb);
    curvvs = vvs(bb);
    o = [curuus' curvvs'] - t.padder;
    bbs = ([o(:,2) o(:,1) o(:,2)+size(ws{modelIdx},2) ...
           o(:,1)+size(ws{modelIdx},1)] - 1) .* ...
             repmat(sbin./scales',1,4) + 1 + repmat([0 0 -1 ...
                    -1],length(scales),1);
    bbs(:,5:12) = 0;
    bbs(:,5) = (1:size(bbs,1));
    bbs(:,6) = modelIdx;
    bbs(:,8) = scales;
    bbs(:,9) = uus(bb);
    bbs(:,10) = vvs(bb);
    bbs(:,12) = sorted_scores;
    if (params.detect_add_flip == 1)
        bbs = flip_box(bbs,t.size);
        bbs(:,7) = 1;
    end
    resstruct.activeBboxesIdx{exid} = bb;
    resstruct.activeBboxesIdxFlat{exid} = sub2ind(size(r),...
      repmat(exid,[1 length(bb)]),bb);
    resstruct.bbs{modelIdx} = [resstruct.bbs{modelIdx};bbs];
end
resstruct.activeBboxesIdxFlat = cat(2,resstruct.activeBboxesIdxFlat{:});

function [rs preserved_idx] = prune_nms(rs,activeBboxesIdx,params)
%Prune via nms to eliminate redundant detections
%If the field is missing, or it is set to 1, then we don't need to
%process anything.  If it is zero, we also don't do NMS.
preserved_idx = [];
if ~isfield(params,'detect_exemplar_nms_os_threshold') || (params.detect_exemplar_nms_os_threshold >= 1) ...
      || (params.detect_exemplar_nms_os_threshold == 0)
  return;
end

[rs.bbs preserved_idx] = cellfun(@(x,y)esvm_nms(x(y,:),params.detect_exemplar_nms_os_threshold),...
    rs.bbs,activeBboxesIdx,'uniformoutput',false);

function t = get_pyramid(I, sbin, params)
%Extract feature pyramid from variable I (which could be either an image,
%or already a feature pyramid)

if isnumeric(I)
  if (params.detect_add_flip == 1)
    I = flip_image(I);
  else    
    %take unadulterated "aka" un-flipped image
  end
  
  clear t
  t.size = size(I);

  %Compute pyramid
  [t.hog, t.scales] = esvm_pyramid(I, params);
  t.padder = params.detect_pyramid_padding;
  for level = 1:length(t.hog)
    t.hog{level} = padarray(t.hog{level}, [t.padder t.padder 0], 0);
  end
  
  minsizes = cellfun(@(x)min([size(x,1) size(x,2)]), t.hog);
  t.hog = t.hog(minsizes >= t.padder*2);
  t.scales = t.scales(minsizes >= t.padder*2);  
else
  fprintf(1,'Already found features\n');
  
  if iscell(I)
    if params.detect_add_flip==1
      t = I{2};
    else
      t = I{1};
    end
  else
    t = I;
  end
end

