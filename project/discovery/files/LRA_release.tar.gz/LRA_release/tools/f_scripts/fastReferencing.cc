#include "mex.h"
#include "blas.h"
#include <pthread.h>
#include <math.h>
#include <string.h>
#include <iostream>
#include <vector>

void setDoubleArray(double* TOArray, double* FROMArray, mwSize t){
    for(long i = 0;i<t;i++){
        //mexPrintf("copy the %lu th scalar\n",i);
        TOArray[i]=FROMArray[i];
    }
}

void processLut(double* resp,double* lut,double* cache_resp,const mwSize* lut_dims,double* wordIdx,const mwSize* wordIdx_dims, int dispIdx){
    // add response for one displacement with cache strategy
    const long wordIdxStartingIdx = wordIdx_dims[0]*dispIdx;
    //mexPrintf("lut h=%d, lut w=%d\n",lut_dims[0],lut_dims[1]);
    //mexPrintf("wordIdx h=%d, wordIdx w=%d\n",wordIdx_dims[0],wordIdx_dims[1]);
    //mexPrintf("wordIdxStartingIdx=%lu\n",wordIdxStartingIdx);
    long word = 0;
    long resp_counter = 0;
    int isCache = 0;
    //mexPrintf("I am here!\n");
    if (isCache == 1){
        // seed the first cache
        long cache_word = wordIdx[wordIdxStartingIdx];
        setDoubleArray(cache_resp, lut+(cache_word-1)*lut_dims[0], lut_dims[0]);
        for (int i = 0;i<wordIdx_dims[0];i++){
        word = wordIdx[i+wordIdxStartingIdx];
        //mexPrintf("the %d th column, word=%lu\n",i,word);
        if (word==cache_word)
        {
            for (int j = 0;j<lut_dims[0];j++){
                resp[resp_counter] = resp[resp_counter] + cache_resp[j];
                resp_counter = resp_counter + 1;
            }
        }
        else
        {
            for (int j = 0;j<lut_dims[0];j++){
                resp[resp_counter] = resp[resp_counter] + lut[(word-1)*lut_dims[0]+j];
                resp_counter = resp_counter + 1;
            }
            setDoubleArray(cache_resp, lut+(word-1)*lut_dims[0], lut_dims[0]);
        }
        cache_word = word;
        }
    }
    else
    {
        for (int i = 0;i<wordIdx_dims[0];i++){
            word = wordIdx[i+wordIdxStartingIdx];
            for (int j = 0;j<lut_dims[0];j++){
                resp[resp_counter] = resp[resp_counter] + lut[(word-1)*lut_dims[0]+j];
                resp_counter = resp_counter + 1;
            }
        }
    }
}


//double* prepare_lut_double(double* lut, const mwSize* lut_dims){
//    double *F = (double *)mxCalloc(lut_dims[0]*lut_dims[1], sizeof(double));
//    for (int i=0;i<lut_dims[0],i++){
//        for (int j=0;j<lut_dims[1],j++){
//            F[j + i*lut_dims[0]] =
//                lut[j + i*lut_dims[0]];
//        }
//    }
//    return F;
//}

//double* prepare_wordIdx(double* wordIdx, const mwSize* wordIdx_dims){
//    double *F = (double *)mxCalloc(wordIdx_dims[0]*wordIdx_dims[1], sizeof(double));
//    for (int i=0;i<wordIdx_dims[0],i++){
//        for (int j=0;j<wordIdx_dims[1],j++){
//            F[j + i*wordIdx_dims[0]] =
//                wordIdx[j + i*wordIdx_dims[0]];
//        }
//    }
//    return F;
//}

// fast version of referencing
// r = fastReferencing(wordIdx,lutStruct.lut);
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    if (nrhs != 2) {
    mexErrMsgTxt("fastReferencing.cc: Wrong number of inputs");
    }
    if (nlhs != 1)
    mexErrMsgTxt("fastReferencing.cc: Wrong number of outputs");
    // get wordIdx
    const mxArray* wordIdx = prhs[0];
    const mwSize* wordIdx_dims = mxGetDimensions(wordIdx);
    // get lut
    const mxArray* lutCellPtr = prhs[1];
    if (mxGetClassID(lutCellPtr) != mxCELL_CLASS)
        mexErrMsgTxt("fastReferencing.cc: Invalid input lut, must be a cell array\n");
    const mwSize num_lut = mxGetNumberOfElements(lutCellPtr);
    mxArray* lut0 = mxGetCell(lutCellPtr, 0);
    if (lut0 == NULL)
        mexErrMsgTxt("fastReferencing.cc: lut has no content\n");
    const mwSize* lut_dims = mxGetDimensions(lut0);
    if (num_lut != wordIdx_dims[1])
        mexErrMsgTxt("fastReferencing.cc: Dimension mismatch between lut and wordIdx\n");

    // compute the response at each displacement
    //double* curWordIdx = prepare_wordIdx((double*)mxGetPr(wordIdx), wordIdx_dims);
    double* curWordIdx = (double*)mxGetPr(wordIdx);
    mwSize* resp_dims = (mwSize*)mxCalloc(2,sizeof(mwSize));
    resp_dims[0] = lut_dims[0];
    resp_dims[1] = wordIdx_dims[0];
    mxArray* mxResp = mxCreateNumericArray(2, resp_dims, mxDOUBLE_CLASS, mxREAL);
    double* doubleResp = (double*)mxGetPr(mxResp);
    double* cur_lut;
    double* cache_resp = (double*)mxCalloc(lut_dims[0],sizeof(double));

    for(int i = 0;i<num_lut;i++){
        mxArray* cur_lut_ptr = mxGetCell(lutCellPtr,i);
        //cur_lut = prepare_lut_double((double*)mxGetPr(cur_lut_ptr),lut_dims);
        cur_lut = (double*)mxGetPr(cur_lut_ptr);
        processLut(doubleResp,cur_lut,cache_resp,lut_dims,curWordIdx,wordIdx_dims,i);
    }
    plhs[0] = mxResp;
    mxFree(cache_resp);
}


