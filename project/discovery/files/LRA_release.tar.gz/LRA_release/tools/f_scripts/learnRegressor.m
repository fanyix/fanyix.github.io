function [WClosed bClosed] = learnRegressor(R,X,lambda)
[M N] = size(R);
D = size(X,1);
XXTLambda = (1/N)*(X*X') + lambda*eye(D);

Xmean = mean(X,2);
Rmean = mean(R,2);

% % check gradient
% WClosed2 = rand(M,D);
% [val J] = newFuncVal(vec(WClosed2),R,X,lambda);
% [numgrad] = computeNumericalGradient(@(x)newFuncVal(x,R,X,lambda), vec(WClosed2));
% disp([J numgrad]); 

Left = XXTLambda - Xmean*Xmean';
Right = 1/N*(R*X') - Rmean*Xmean'; 
invLeft = pinv(Left);
WClosed = Right*invLeft;
bClosed = mean(R-WClosed*X,2);

% WClosedEfficient = ((Left')\(Right'))';
% bClosedEfficient = mean(R-WClosedEfficient*X,2);
% [val grad] = newFuncVal(WClosed,R,X,lambda);
% [valEfficient gradEfficient] = newFuncVal(WClosedEfficient,R,X,lambda);

% funcVal(R,X,WClosed1,bClosed1,lambda)
% WClosed2 = ((Left')\(Right'))';
% bClosed2 = mean(R-WClosed2*X,2);
% [val1 grad1] = newFuncVal(WClosed1,R,X,lambda);
% [val2 grad2] = newFuncVal(WClosed2,R,X,lambda);
% funcVal(R,X,WClosed2,bClosed2,lambda)


function val = funcVal(R,X,W,b,lambda)
N = size(X,2);
val = 0.5/N*norm(R-bsxfun(@plus,W*X,b),'fro')^2 + lambda*0.5*norm(W,'fro')^2;

function [val grad] = newFuncVal(W,R,X,lambda)
M = size(R,1);
D = size(X,1);
N = size(X,2);
W = reshape(W,[M D]);
b = mean(R-W*X,2);
val = 0.5/N*norm(R-bsxfun(@plus,W*X,b),'fro')^2 + lambda*0.5*norm(W,'fro')^2;
Xmean = mean(X,2);
Rmean = mean(R,2);
grad = 1/N*(W*(X*X'))+Rmean*Xmean'-W*(Xmean*Xmean')-1/N*(R*X')+lambda*W;
grad = vec(grad);
