function mkdir_recursive(folder)

if isunix
    paths = regexp(folder,'/','split');
else
    paths = regexp(folder,'\','split');
end

val_idx = cellfun(@(x)~isempty(x),paths);
paths = paths(val_idx);

curstr = [];
for i = 1:length(paths)
    curstr = fullfile(curstr,paths{i});
    if ~exist(curstr,'dir')
        mkdir(curstr);
    end
end