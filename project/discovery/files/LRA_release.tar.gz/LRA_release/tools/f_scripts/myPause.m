function [count isBreak] = myPause(count,maxval)
isBreak = 0;
[ignore ignore button] = ginput(1);
if button == 29 % --> 
    if count<maxval
        count = count + 1;
    end
elseif button == 28 % <--
    if count>1
        count = count - 1;
    end
elseif button == 110 % 'n'
    isBreak = 1;
end