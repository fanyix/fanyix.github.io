function mySaveFile(filename,varargin)
myDir = fileparts(filename);
if ~isempty(myDir)
    if ~exist(myDir,'dir')
        mkdir(myDir);
    end
end
varName = cell(length(varargin),1);
for i = 1:length(varargin)
    varName{i} = inputname(i+1);
end
% check if there are duplicate names
if length(unique(varName)) < length(varName)
    error('Duplicate variables!');
end
for i = 1:length(varargin)
    eval(sprintf('%s=varargin{%d};',varName{i},i));
end
ws = warning('error', 'MATLAB:save:sizeTooBigForMATFile');
try
    save(filename,varName{:});
catch
    save(filename,varName{:},'-v7.3');
end
warning(ws);
