function feat = phowSP(I,dictionary)
NDict = size(dictionary,1);
if ndims(I) == 3
    I = rgb2gray(I);
end
I = single(I);

% internal parameters
maxDim = 300;
SIFTLevels = 3;
downsampleRate = 0.5;
numSpatialY = 2;
numSpatialX = 2;



% resize I 
[height width] = size(I);
if max(height,width)>maxDim
    ratio = maxDim/max(height,width);
    I = imresize(I,ratio);
end
[height width] = size(I);

frames = cell(SIFTLevels,1);
descrs = cell(SIFTLevels,1);
for i = 1:SIFTLevels
    [frames{i}, descrs{i}] = vl_dsift(I,'size',10,'step',5);
    frames{i} = frames{i}./(downsampleRate^(i-1));
    if i~=SIFTLevels
        I = imresize(I,downsampleRate);
    end
end
frames = cat(2,frames{:});
descrs = double(cat(2,descrs{:}));
descrs = bsxfun(@rdivide,descrs,sqrt(sum(descrs.^2,1)));

% vector quantization
dist = pdist2(dictionary,descrs');
[ignore code] = min(dist,[],1);

% SC
% TO BE IMPLEMENTED

binsx = vl_binsearch(linspace(1,width,numSpatialX+1), frames(1,:)) ;
binsy = vl_binsearch(linspace(1,height,numSpatialY+1), frames(2,:)) ;
bins = sub2ind([NDict, numSpatialY, numSpatialX],code,binsy,binsx);
feat = zeros(numSpatialY * numSpatialX * NDict, 1);
feat = vl_binsum(feat, ones(size(bins)), bins);
feat = feat/norm(feat);

