function [quantizedStruct] = quantizeOMP(I,dict,scanningBboxSize,quantizeBboxSize,params)

isFlipDet = params.detect_add_flip;
if isFlipDet
    params.detect_add_flip = 0;
    quantizedStruct = quantizeOMPDriver(I,dict,scanningBboxSize,quantizeBboxSize,params);
    params.detect_add_flip = 1;
    quantizedStructFlipped = quantizeOMPDriver(I,dict,scanningBboxSize,quantizeBboxSize,...
        params);
    finalQuantizedStruct{1} = quantizedStruct;
    finalQuantizedStruct{2} = quantizedStructFlipped;
    quantizedStruct = finalQuantizedStruct;
else
    params.detect_add_flip = 0;
    quantizedStruct = quantizeOMPDriver(I,dict,scanningBboxSize,quantizeBboxSize,params);
end
    

function [quantizedStruct] = quantizeOMPDriver(I,dict,scanningBboxSize,quantizeBboxSize,...
    params)
% quantize the image for efficient detection
fsize = params.init_params.features();
sbin = params.init_params.sbin;
hSB = scanningBboxSize(1);
wSB = scanningBboxSize(2);
hQB = quantizeBboxSize(1);
wQB = quantizeBboxSize(2);
testOMPParam.L = params.OMPLambda;


t = get_pyramid(I, sbin, params);
quantizedStruct.padder = t.padder;
available_size = cellfun(@(x)[size(x,1) size(x,2)]-quantizeBboxSize+1,t.hog,...
    'uniformoutput',false);
available_size = cat(1,available_size{:});
valLevelIdx = find(sum(available_size<=0,2)==0);

pyr_N = prod(available_size(valLevelIdx,:),2);
sumN = sum(pyr_N);

X = zeros(hQB*wQB*fsize,sumN);
offsets = cell(length(valLevelIdx), 1);
uus = cell(length(valLevelIdx),1);
vvs = cell(length(valLevelIdx),1);

% % get feature for scanning windows
% sX = zeros(hSB*wSB*fsize,sumN);
% counter = 1;
% for i = 1:length(valLevelIdx)
%   s = size(t.hog{valLevelIdx(i)});
%   NW = s(1)*s(2);
%   ppp = reshape(1:NW,s(1),s(2));
%   curf = reshape(t.hog{valLevelIdx(i)},[],fsize);
%   b = im2col(ppp,[hSB wSB]);
%   for j = 1:size(b,2)
%    sX(:,counter) = reshape(curf(b(:,j),:),[],1);
%    counter = counter + 1;
%   end
% end

% get features for quantize windows
counter = 1;
for i = 1:length(valLevelIdx)
  s = size(t.hog{valLevelIdx(i)});
  NW = s(1)*s(2);
  ppp = reshape(1:NW,s(1),s(2));
  curf = reshape(t.hog{valLevelIdx(i)},[],fsize);
  b = im2col(ppp,[hQB wQB]);
  offsets{i} = b(1,:);
  offsets{i}(end+1,:) = valLevelIdx(i);
  for j = 1:size(b,2)
   X(:,counter) = reshape(curf(b(:,j),:),[],1);
   counter = counter + 1;
  end
  [uus{i},vvs{i}] = ind2sub(s,offsets{i}(1,:));
end
uus = cat(2,uus{:});
vvs = cat(2,vvs{:});
offsets = cat(2,offsets{:});

% quantize the hog feature
X = single(X);
switch params.accelerationOption
    case 1 % OMP
        AOMP=mexOMP(X,dict,testOMPParam);
        quantizedStruct.AOMP = AOMP;
    case 2 % nearest neighbor
        distMat = pdist2(X',dict');
        [distMat wordIdx] = min(distMat,[],2);
        quantizedStruct.wordIdx = wordIdx;
end

% create the linker
hGroupIdxSeq = mod(uus-1,quantizeBboxSize(1))+1;
wGroupIdxSeq = mod(vvs-1,quantizeBboxSize(2))+1;
uHGroupIdx = unique(hGroupIdxSeq);
uWGroupIdx = unique(wGroupIdxSeq);
linker = cell(length(uWGroupIdx)*length(uHGroupIdx),1);
counter = 1;
for i = 1:length(uWGroupIdx)
    wGroupIdx = uWGroupIdx(i);
    for j = 1:length(uHGroupIdx)
        hGroupIdx = uHGroupIdx(j);
        valIdx = find(wGroupIdxSeq == wGroupIdx & hGroupIdxSeq == hGroupIdx);
        uLevels = unique(offsets(2,valIdx));
        linker{counter}.levels = uLevels;
        for k = 1:length(uLevels) 
            subValIdx = valIdx(uLevels(k) == offsets(2,valIdx));
            linker{counter}.idx{k} = reshape(subValIdx, ...
                [(max(uus(subValIdx))-min(uus(subValIdx)))/hQB+1,...
                (max(vvs(subValIdx))-min(vvs(subValIdx)))/wQB+1]);
            linker{counter}.offsets{k} = offsets(1,subValIdx);
        end
        linker{counter}.hGroupIdx = hGroupIdx;
        linker{counter}.wGroupIdx = wGroupIdx;
        counter = counter + 1;
    end
end

% manufacture the long quantized feature
hBin = round(hSB/hQB);
wBin = round(wSB/wQB);
codeCollector = cell(length(valLevelIdx),1);
locCollector = cell(length(valLevelIdx),1);
for i = 1:length(valLevelIdx)
    [valLinkerIdxSeq innerLinkerIdxSeq] = cellfun(@(x)ismember(valLevelIdx(i),x.levels),linker);
    valLinkerIdxSeq = find(valLinkerIdxSeq);
    if isempty(valLinkerIdxSeq)
        continue;
    end
    idxCollector = cell(length(valLinkerIdxSeq),1);
    startingIdxCollector = cell(length(valLinkerIdxSeq),1);
    for j = 1:length(valLinkerIdxSeq)
        valLinkerIdx = valLinkerIdxSeq(j);
        innerLinkerIdx = innerLinkerIdxSeq(valLinkerIdx);
        idxCollector{j} = im2col(linker{valLinkerIdx}.idx{innerLinkerIdx},[hBin wBin]);
        startingIdx = im2col(reshape(1:numel(linker{valLinkerIdx}.idx{innerLinkerIdx}),...
            size(linker{valLinkerIdx}.idx{innerLinkerIdx})),[hBin wBin]);
        startingIdx = startingIdx(1,:);
        startingIdxCollector{j} = linker{valLinkerIdx}.offsets{innerLinkerIdx}(startingIdx);
    end
    startingIdxCollector = cat(2,startingIdxCollector{:});
    idxCollector = cat(2,idxCollector{:});
    [sortval sortidx] = sort(startingIdxCollector,'ascend');
    codeCollector{i} = idxCollector(:,sortidx);
    locCollector{i}(1,:) = sortval;
    locCollector{i}(2,:) = valLevelIdx(i);
    [locCollector{i}(3,:) locCollector{i}(4,:)] = ind2sub([size(t.hog{valLevelIdx(i)},1) ...
        size(t.hog{valLevelIdx(i)},2)],sortval);
end
codeCollector = cat(2,codeCollector{:});
locCollector = cat(2,locCollector{:});

quantizedStruct.offsets = locCollector(1,:);
quantizedStruct.levels = locCollector(2,:);
quantizedStruct.scales = t.scales(quantizedStruct.levels);
quantizedStruct.uus = locCollector(3,:);
quantizedStruct.vvs = locCollector(4,:);
quantizedStruct.codes = codeCollector;
quantizedStruct.imgSize = t.size;
quantizedStruct.X = double(X);
