function [quantizedStruct] = quantizeOMPDebug(I,dict,scanningBboxSize,...
    quantizeBboxSize,params)
% quantize the image for efficient detection
fsize = params.init_params.features();
sbin = params.init_params.sbin;
hSB = scanningBboxSize(1);
wSB = scanningBboxSize(2);
hQB = quantizeBboxSize(1);
wQB = quantizeBboxSize(2);
testOMPParam.L = params.OMPLambda;


t = get_pyramid(I, sbin, params);
quantizedStruct.padder = t.padder;
available_size = cellfun(@(x)[size(x,1) size(x,2)]-scanningBboxSize+1,t.hog,...
    'uniformoutput',false);
available_size = cat(1,available_size{:});
valLevelIdx = find(sum(available_size<=0,2)==0);

pyr_N = prod(available_size(valLevelIdx,:),2);
sumN = sum(pyr_N);

X = zeros(hSB*wSB*fsize,sumN);
offsets = cell(length(valLevelIdx), 1);
uus = cell(length(valLevelIdx),1);
vvs = cell(length(valLevelIdx),1);

counter = 1;
for i = 1:length(valLevelIdx)
  s = size(t.hog{valLevelIdx(i)});
  NW = s(1)*s(2);
  ppp = reshape(1:NW,s(1),s(2));
  curf = reshape(t.hog{valLevelIdx(i)},[],fsize);
  b = im2col(ppp,[hSB wSB]);
  offsets{i} = b(1,:);
  offsets{i}(end+1,:) = valLevelIdx(i);
  for j = 1:size(b,2)
   X(:,counter) = reshape(curf(b(:,j),:),[],1);
   counter = counter + 1;
  end
  [uus{i},vvs{i}] = ind2sub(s,offsets{i}(1,:));
end
uus = cat(2,uus{:});
vvs = cat(2,vvs{:});
offsets = cat(2,offsets{:});

% quantize the hog feature
wBin = round(wSB/wQB);
hBin = round(hSB/hQB);
counter = 1;
AOMP = cell(wBin*hBin,1);
for i = 1:wBin
    for j = 1:hBin
        mask = false(hSB,wSB,fsize);
        mask((j-1)*hQB+1:j*hQB,(i-1)*wQB+1:i*wQB,:) = true;
        mask = mask(:);
        XToBeCoded = X(mask,:);
        XToBeCoded = single(XToBeCoded);
        AOMP{counter}=mexOMP(XToBeCoded,dict,testOMPParam);
        counter = counter + 1;
    end
end

quantizedStruct.offsets = offsets(1,:);
quantizedStruct.levels = offsets(2,:);
quantizedStruct.uus = uus;
quantizedStruct.vvs = vvs;
quantizedStruct.AOMP = AOMP;
% quantizedStruct.linker = linker;

