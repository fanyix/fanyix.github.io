function [negSampledBboxes] = sampleNegBboxes(...
    gtbboxes,img_size,NNeg,negThresh,minLength,seedingNeeded)

if seedingNeeded
    myRandSeeding;
end

debug = 0;
blankImg = zeros(img_size(1),img_size(2),3);
if debug
    for i = 1:size(gtbboxes,1)
        blankImg = plot_bb(blankImg,gtbboxes(i,:),'g');
    end
end
% sample neg bboxes
NCount = 0;
negSampledBboxes = [];
while 1
    samples = rand(2,1);
    upperLeft = [max(1,round(samples(1)*(img_size(2)-minLength))) max(1,round(samples(2)*(img_size(1)-minLength)))];  
    bottomRight = upperLeft+ [minLength minLength] + [round(img_size(2)-upperLeft(1)-minLength)*samples(1) ...
        round(img_size(1)-upperLeft(2)-minLength)*samples(2)];
    sampled_bbox = [upperLeft bottomRight];
    sampled_bbox = clip_to_image(round(sampled_bbox),[1 1 img_size(2) img_size(1)]);
    
    if debug
        curI = plot_bb(blankImg,sampled_bbox,'r');
        imshow(curI);
    end
    
    if ~isempty(gtbboxes)
        if max(getosmatrix_bb(sampled_bbox,gtbboxes)) < negThresh
            negSampledBboxes = [negSampledBboxes; sampled_bbox];
            NCount = NCount + 1;
            if NCount >= NNeg
                break;
            end
        end
    else
        negSampledBboxes = [negSampledBboxes; sampled_bbox];
        NCount = NCount + 1;
        if NCount >= NNeg
            break;
        end
    end
end








