function batchSeq = unSyncDistribute(NModels,NBatch)
if mod(NModels,NBatch) == 0
    batchSeq = 1:(NModels/NBatch);
else
    batchSeq = 1:(floor(NModels/NBatch)+1);
end