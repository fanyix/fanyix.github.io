function y = vec(x)
y = x(:);