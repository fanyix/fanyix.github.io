function filename=bg_file_name
filename='/home/fanyi/Downloads/generative_RELEASE/data/bg.mat';
